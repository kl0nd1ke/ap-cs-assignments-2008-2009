/* Tester.java
 * Vladimir Costescu
 * AP Computer Science AB
 * Assignment-2.1-PalinTester (due 11/7/08)
 * This is the Tester class, which simply creates an instance of PalinTester and calls its printResults method.
 */

public class Tester {

	public static void main(String[] args) {
		PalinTester tester = new PalinTester();
		tester.printResults();
	}

}
