

public class Tester {

	/*
	public static void main(String[] args) {
		int[][] board = new int[3][3];
		board[0][0] = 1;
		board[0][1] = -1;
		board[0][2] = -1;
		board[1][0] = 1;
		board[1][1] = -1;
		board[1][2] = 1;
		board[2][0] = 0;
		board[2][1] = 0;
		board[2][2] = -1;
		TicTacToeState state = new TicTacToeState(-1, board);
		state.display(System.out);
		System.out.println(state.hasMove());
	}
	*/

}
